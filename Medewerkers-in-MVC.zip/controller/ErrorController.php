<?php

	function error_404()
	{
		echo "404 - De gevraagde route is niet beschikbaar. Controleer je controller en action naam";
	}