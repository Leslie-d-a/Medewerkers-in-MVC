Vergeet niet de config.php voor gebruik aan te passen aan jouw ontwikkel omgeving.
